<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">User</h1>
    
</div>

<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        User Form
    </div>
    <div class="card-body">
        <form class="user" method="post" action="">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <div class="col-sm-6 mb-3">
                    <input type="text" class="form-control" name="full_name" value="<?php echo e(old('full_name')); ?>"
                        placeholder="Full Name">
                    <?php if ($errors->has('full_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('full_name'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="E-Mail">
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <select class="form-control" name="user_role">
                        <option value="">User Role</option>
                        <option value="" <?php if(old('user_role')=='user_role' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Admin
                        </option>
                        <option value="" <?php if(old('user_role')=='user_role' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Account
                        </option>
                        <option value="" <?php if(old('user_role')=='user_role' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>User
                        </option>
                    </select>
                    <?php if ($errors->has('user_role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('user_role'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="Password">
                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <input type="password" class="form-control" name="confirm" value="<?php echo e(old('confirm')); ?>" placeholder="Comfirm">
                    <?php if ($errors->has('confirm')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('confirm'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>
            <div class="texr-center">
                <button type="submit" class="btn btn-info">Create New User</button>
                <button type="reset" class="btn btn-warning">Reset</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\InstalledSoft\xampp\htdocs\Laravel\property-management\resources\views/user/user_create.blade.php ENDPATH**/ ?>