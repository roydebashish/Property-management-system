<?php if(Session::has('success') || Session::has('warning')): ?>
<div class="col-md-12 text-center">
  <div
    class="alert <?php if(Session::has('success')): ?><?php echo e('alert-primary'); ?> <?php else: ?> <?php echo e('alert-warning'); ?> <?php endif; ?> alert-dismissible fade show"
    role="alert">
    <?php if(Session::has('success')): ?>
    <?php echo e(Session::get('success')); ?>

    <?php endif; ?>
    <?php if(Session::has('warning')): ?>
    <?php echo e(Session::get('warning')); ?>

    <?php endif; ?>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
</div>
<?php endif; ?><?php /**PATH E:\InstalledSoft\xampp\htdocs\Laravel\property-management\resources\views/alert.blade.php ENDPATH**/ ?>