<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Member</h1>
    
</div>

<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        Member Create Form
    </div>
    <div class="card-body">
        <form class="user" method="post" action="">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <div class="col-sm-6 mb-3">
                    <input type="text" class="form-control" name="member_name" value="<?php echo e(old('member_name')); ?>"
                        placeholder="Member Name">
                    <?php if ($errors->has('member_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('member_name'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="E-Mail">
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <select class="form-control" name="country_id">
                        <option value="">Country</option>
                        <option value="" <?php if(old('country_id')=='country_id' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Bangladesh
                        </option>
                        <option value="" <?php if(old('country_id')=='country_id' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Malayasia
                        </option>
                    </select>
                    <?php if ($errors->has('country_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('country_id'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <input type="text" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="Phone">
                    <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <input type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>" placeholder="Address">
                    <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <input type="date" class="form-control" name="dob" value="<?php echo e(old('dob')); ?>" placeholder="Address">
                    <?php if ($errors->has('dob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dob'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>
            <div class="texr-center">
                <button type="submit" class="btn btn-info">Create New Member</button>
                <button type="reset" class="btn btn-warning">Reset</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\InstalledSoft\xampp\htdocs\Laravel\property-management\resources\views/member/member_create.blade.php ENDPATH**/ ?>