<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Sale</h1>
    
</div>

<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        Sale Create Form
    </div>
    <div class="card-body">
        <form class="user" method="post" action="">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <div class="col-sm-6 mb-3">
                    
                    <select class="form-control" name="country_id">
                        <option value="">Country</option>
                        <option value="" <?php if(old('country_id')=='country_id' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Bangladesh</option>
                        <option value="" <?php if(old('country_id')=='country_id' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Malayasia</option>
                    </select>
                    <?php if ($errors->has('country_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('country_id'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <select class="form-control" name="property_id">
                        <option value="">Property</option>
                        <option value="" <?php if(old('property_id')=='property_id' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Property 1</option>
                        <option value="" <?php if(old('property_id')=='property_id' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Property 2</option>
                    </select>
                    <?php if ($errors->has('property_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('property_id'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <select class="form-control" name="unit_id">
                        <option value="">Unit</option>
                        <option value="" <?php if(old('unit_id')=='unit_id' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Unit 1</option>
                        <option value="" <?php if(old('unit_id')=='unit_id' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Unit 2</option>
                    </select>
                    <?php if ($errors->has('unit_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('unit_id'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <select class="form-control" name="member_id">
                        <option value="">Member</option>
                        <option value="" <?php if(old('member_id')=='member_id' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Member 1</option>
                        <option value="" <?php if(old('member_id')=='member_id' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Member 2</option>
                    </select>
                    <?php if ($errors->has('member_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('member_id'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <input type="text" class="form-control" name="sale_amount" value="<?php echo e(old('sale_amount')); ?>" placeholder="Sale Amount">
                    <?php if ($errors->has('mesale_amountdium')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mesale_amountdium'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <select class="form-control" name="payment_method">
                        <option value="">Payment Method</option>
                        <option value="" <?php if(old('payment_method')=='payment_method' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Method 1</option>
                        <option value="" <?php if(old('payment_method')=='payment_method' ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Method 2</option>
                    </select>
                    <?php if ($errors->has('payment_method')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('payment_method'); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>
            <div class="texr-center">
                <button type="reset" class="btn btn-warning">Reset</button>
                <button type="submit" class="btn btn-info">Confirm Sale</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\InstalledSoft\xampp\htdocs\Laravel\property-management\resources\views/sale/sale_create.blade.php ENDPATH**/ ?>